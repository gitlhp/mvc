package jdbc.conn;

import java.sql.DriverManager;
import java.sql.Connection;

public class conn {
  public Connection getConnection()
  {
	  try {
		  Class.forName("com.mysql.jdbc.Driver");
		  String url="jdbc:mysql://localhost:3306/jkxystudent?userUnicode=true&characterEncoding=UTF-8";
		  String user="root";
		  String password="";
		  Connection conn=(Connection) DriverManager.getConnection(url, user, password);//DriverManager.getConnection()。该方法将建立与数据库的链接。
		  System.out.println(conn.getMetaData().getUserName());
		  return conn;
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return null;
	}
	   
  }
}
