package jdbc.test;

import org.apache.jasper.tagplugins.jstl.core.Out;

import com.mysql.jdbc.Connection;

import jdbc.conn.conn;


public class test {
	
	public static void main(String[] args) {
		
	new conn().getConnection();
		
	}

}
