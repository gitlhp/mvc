package javabean.service;
import java.util.List;
import java.sql.ResultSet;

import javabean.model.studentbean;
import javabean.model.userbean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;


public class stuservice {
		private Connection conn;
		private PreparedStatement pstmt;
	public stuservice(){
		conn=new jdbc.conn.conn().getConnection();
}
		//添加信息
	public boolean addstu(studentbean student){
		try {
			String sql ="insert into student (nicheng,name,sex,data,zhuanye,course,interst,beizhu) values (?,?,?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql);//Statement对象用于将SQL语句发送到数据库中。	
			pstmt.setString(1, student.getNicheng());
			pstmt.setString(2, student.getName());
			pstmt.setByte(3, student.getSex());
			pstmt.setString(4, student.getData());
			pstmt.setString(5, student.getZhuanye());
			pstmt.setString(6, student.getCoursestrString());
			pstmt.setString(7, student.getInterString());
			pstmt.setString(8, student.getBeizhu());
			pstmt.executeUpdate();
			return true;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}	
	}
	//查询信息
public  List stuList() {
	List stuList=new ArrayList();
	try {
		pstmt=conn.prepareStatement("select * from student");
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			studentbean student=new studentbean();
			student.setId(rs.getInt(1));
			student.setNicheng(rs.getString(2));
			student.setName(rs.getString(3));
			student.setSex(rs.getByte(4));
			if (rs.getDate(5)!=null) {
			student.setData(rs.getDate(5).toString());
			}
			student.setZhuanye(rs.getString(6));
			if (rs.getString(7)!=null) {
				student.setCourse(rs.getString(7).split("&"));
			}
			if (rs.getString(8)!=null) {
				student.setInterst(rs.getString(8).split("&"));
			}
			student.setBeizhu(rs.getString(9));
			stuList.add(student);
			
		}
		return stuList;
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return null;
	}
	
}
//查询一个学生信息，
public studentbean selectstu(int id) {
	try {
		String sql="select * from student where id=?";
		pstmt=conn.prepareStatement(sql);//创建向数据库发送预编译sql的PrepareSatement对象。就是创建一个将要执行这条语句的对象
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		if (rs.next()) {
			studentbean student=new studentbean();
			student.setId(rs.getInt(1));
			student.setNicheng(rs.getString(2));
			student.setName(rs.getString(3));
			student.setSex(rs.getByte(4));
			if (rs.getDate(5)!=null) {
				student.setData(rs.getDate(5).toString());
			}
			student.setZhuanye(rs.getString(6));
			if (rs.getString(7)!=null) {
				student.setCourse(rs.getString(7).split("&"));
			}
			if (rs.getString(8)!=null) {
				student.setInterst(rs.getString(8).split("&"));// 将字符串分割成字符串数组
			}
			student.setBeizhu(rs.getString(9));
			return student;
		}
		return null;//1
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return null;//2  1和2 返回不一样
	}
	
}
//更新学生信息返回bool值
public  boolean updatetu_result(studentbean student) {
	try {
		String sql="update student set nicheng=?,name=?,sex=?,data=?,zhuanye=?,course=?,interst=?,beizhu=? where id=? ";
		pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, student.getNicheng());
		pstmt.setString(2, student.getName());
		pstmt.setByte(3, student.getSex());
		pstmt.setString(4, student.getData());
		pstmt.setString(5, student.getZhuanye());
		pstmt.setString(6, student.getCoursestrString());
		pstmt.setString(7, student.getInterString());
		pstmt.setString(8, student.getBeizhu());
		pstmt.setInt(9, student.getId());
		pstmt.executeUpdate();
		return true;
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return false;
	}
}
//删除一个学生
public boolean deletestu(int id) {
	try {
		String sql="delete from student where id=?";
		pstmt=conn.prepareStatement(sql);//它表示一条预编译过的 SQL 语句
		pstmt.setInt(1, id);
		pstmt.executeUpdate();//正式运行
		return true;
		
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return false;
	}
}
}
/*PreparedStatement与prepareStatement的区别
PreparedStatement是一个类，是一个对象的类型；prepareStatement是connection对象的方法，它返回的是PreparedStatement类型，参数是预编译的sql语句，与值有关的全部用?代替。
PreparedStatement的setObject（key，value）方法：
key是整数1、2、3、4等，它表示第几个问号
value是填入的第几个问号的值。

但是如果相同句法的SQL语句要执行多次，setObject（key，value）方法要重复多次
如果预编译的sql语句中问号的个数是n，要执行的sql语句的次数是m，则setObject（key，value）方法要重复的次数是n*m
所以我们常常有自定义的方法：*/
