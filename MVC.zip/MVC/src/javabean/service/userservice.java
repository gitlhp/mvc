package javabean.service;

import java.sql.ResultSet;

import javabean.model.userbean;

import java.sql.Connection;
import java.sql.PreparedStatement;
public class userservice {
private Connection conn;
private PreparedStatement pstmt;
public userservice(){
	conn=new jdbc.conn.conn().getConnection();
}
public boolean valiuser(userbean user){
	try {
		pstmt=conn.prepareStatement("select * from user where username=? and password=?");
		pstmt.setString(1, user.getUsername());
		pstmt.setString(2, user.getPassword());
		ResultSet rs=pstmt.executeQuery();
		if (rs.next()) {
			return true;
		}
		else {
			return false;
		}
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return false;
	}
	
}
}
