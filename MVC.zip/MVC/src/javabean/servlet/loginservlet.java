package javabean.servlet;

import javabean.model.userbean;
import javabean.service.userservice;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class loginservlet extends HttpServlet{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public void doPost(HttpServletRequest request,HttpServletResponse response) {
	String username=request.getParameter("username");
	String password=request.getParameter("password");
	userbean user=new userbean();
	user.setUsername(username);
	user.setPassword(password);
	try {
		if (new userservice().valiuser(user)) {
			HttpSession session=request.getSession();
			session.setAttribute("user", user);
			response.sendRedirect("../index.jsp");
		}
		else {
			response.sendRedirect("../index.jsp");
		}
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
}
public void doGet(HttpServletRequest request,HttpServletResponse response) {
	doPost(request, response);
}
}
