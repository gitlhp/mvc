package javabean.servlet;

import java.io.IOException;

import javabean.model.studentbean;
import javabean.service.stuservice;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.Out;

/**
 * Servlet implementation class inputstuservlet
 */
@WebServlet("/student/inputstuservlet")
public class inputstuservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public inputstuservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String nicheng=request.getParameter("nicheng");
		String name=request.getParameter("name");
		System.out.print(name);
		byte sex=Byte.parseByte(request.getParameter("sex"));
		String data=request.getParameter("data");
		String zhuanye=request.getParameter("zhuanye");
		String course[]=request.getParameterValues("course");
		String interst[]=request.getParameterValues("interst");
		String beizhu=request.getParameter("beizhu");
		studentbean student=new studentbean();
		student.setNicheng(nicheng);
		student.setName(name);
		student.setSex(sex);
		student.setBeizhu(beizhu);
		if (course!=null) {
			student.setCourse(course);	
		}
		student.setData(data);
		if (data.equals("")) {
			student.setData(null);
		}
		
		student.setZhuanye(zhuanye);
		if (interst!=null) {
			student.setInterst(interst);	
		}
		if (new stuservice().addstu(student)) {
			response.sendRedirect("../inputsuccess.jsp");
		}
		else {
			response.sendRedirect("../updatestu.jsp");
		}
		
	}

}
