package javabean.model;

public class studentbean {
    private int id;
    private String nicheng;
    private String name;
    private byte sex;
    private String data;
    private String zhuanye;
    private String[] course={""};
    private String coursestrString="";
    private String[] interst={""};
    private String interString="";
    private String beizhu;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNicheng() {
		return nicheng;
	}
	public void setNicheng(String nicheng) {
		this.nicheng = nicheng;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public byte getSex() {
		return sex;
	}
	public void setSex(byte sex) {
		this.sex = sex;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getZhuanye() {
		return zhuanye;
	}
	public void setZhuanye(String zhuanye) {
		this.zhuanye = zhuanye;
	}
	public String[] getCourse() {
		return course;
	}
	public void setCourse(String[] course) {
		this.course = course;
	}
	public String getCoursestrString() {
		if (course!=null) {
			coursestrString="";
			for (int i = 0; i < course.length; i++) {
				coursestrString+=course[i]+"&";
			}
		}
		coursestrString=coursestrString.substring(0,coursestrString.length()-1);
		return coursestrString;
	}
	public void setCoursestrString(String coursestrString) {
		this.coursestrString = coursestrString;
	}
	public String[] getInterst() {
		return interst;
	}
	public void setInterst(String[] interst) {
		this.interst = interst;
	}
	public String getInterString() {
		if (interst!=null) {
			interString="";
			for (int i = 0; i < interst.length; i++) {
				interString+=interst[i]+"&";
			}
		}
		interString=interString.substring(0,interString.length()-1);		
		return interString;
	}
	public void setInterString(String interString) {
		this.interString = interString;
	}
	public String getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
    
}
